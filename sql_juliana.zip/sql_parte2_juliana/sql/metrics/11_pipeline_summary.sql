-- Resumo por pipeline/fase com custo estimado em on-demand.
-- Substitua {{REGION}} e informe @PRICE_PER_TIB_USD ao executar.
DECLARE PRICE_PER_TIB_USD FLOAT64 DEFAULT @PRICE_PER_TIB_USD;

WITH jobs AS (
  SELECT
    creation_time,
    end_time,
    total_bytes_processed,
    total_bytes_billed,
    query,
    error_result
  FROM `region-{{REGION}}`.INFORMATION_SCHEMA.JOBS_BY_PROJECT
  WHERE creation_time BETWEEN TIMESTAMP('{{DATE_START}}') AND TIMESTAMP('{{DATE_END}} 23:59:59')
    AND job_type = 'QUERY'
    AND (REGEXP_CONTAINS(query, r'PIPELINE:\s*(ETL|ELT)')
         OR REGEXP_CONTAINS(query, r'python-etl') )
),
base AS (
  SELECT
    creation_time,
    end_time,
    total_bytes_processed,
    total_bytes_billed,
    REGEXP_EXTRACT(query, r'PIPELINE:\s*(ETL|ELT)') AS pipeline,
    REGEXP_EXTRACT(query, r'PHASE:\s*([a-zA-Z_]+)') AS phase
  FROM jobs
  WHERE error_result IS NULL
)
SELECT
  pipeline,
  COALESCE(phase, 'unlabeled') AS phase,
  COUNT(*) AS jobs,
  SUM(TIMESTAMP_DIFF(end_time, creation_time, SECOND)) AS total_seconds,
  SUM(total_bytes_billed) AS total_bytes_billed,
  SUM(total_bytes_billed)/POW(1024,4) AS total_tib_billed,
  (SUM(total_bytes_billed)/POW(1024,4)) * PRICE_PER_TIB_USD AS custo_usd
FROM base
GROUP BY pipeline, phase
ORDER BY pipeline, phase;

-- Uso de armazenamento (logical bytes) por tabela nos datasets do estudo.
SELECT
  table_schema AS dataset,
  table_name,
  active_logical_bytes,
  time_travel_physical_bytes
FROM `{{PROJECT_ID}}.{{ELT_DATASET_GOLD}}`.INFORMATION_SCHEMA.TABLE_STORAGE
UNION ALL
SELECT table_schema, table_name, active_logical_bytes, time_travel_physical_bytes
FROM `{{PROJECT_ID}}.{{ELT_DATASET_SILVER}}`.INFORMATION_SCHEMA.TABLE_STORAGE
UNION ALL
SELECT table_schema, table_name, active_logical_bytes, time_travel_physical_bytes
FROM `{{PROJECT_ID}}.{{ELT_DATASET_RAW}}`.INFORMATION_SCHEMA.TABLE_STORAGE
UNION ALL
SELECT table_schema, table_name, active_logical_bytes, time_travel_physical_bytes
FROM `{{PROJECT_ID}}.{{ETL_DATASET}}`.INFORMATION_SCHEMA.TABLE_STORAGE
ORDER BY dataset, table_name;

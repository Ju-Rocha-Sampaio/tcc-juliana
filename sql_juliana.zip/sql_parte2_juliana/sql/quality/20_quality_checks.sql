-- Indicadores de qualidade aplicados igualmente a ETL e ELT (tabelas finais).
WITH base AS (
  SELECT 'ELT' AS pipeline, * FROM `{{PROJECT_ID}}.{{ELT_DATASET_GOLD}}.fact_trip`
  UNION ALL
  SELECT 'ETL' AS pipeline, * FROM `{{PROJECT_ID}}.{{ETL_DATASET}}.fact_trip`
),
nulos AS (
  SELECT
    pipeline,
    AVG(CASE WHEN trip_id IS NULL THEN 1 ELSE 0 END)*100 AS pct_null_trip_id,
    AVG(CASE WHEN date_key IS NULL THEN 1 ELSE 0 END)*100 AS pct_null_date_key,
    AVG(CASE WHEN start_station_id IS NULL THEN 1 ELSE 0 END)*100 AS pct_null_start_station,
    AVG(CASE WHEN end_station_id IS NULL THEN 1 ELSE 0 END)*100 AS pct_null_end_station,
    AVG(CASE WHEN duration_min IS NULL THEN 1 ELSE 0 END)*100 AS pct_null_duration
  FROM base
  GROUP BY pipeline
),
dups AS (
  SELECT pipeline, 100.0 * SUM(cnt>1)/COUNT(*) AS pct_duplicidade
  FROM (
    SELECT pipeline, trip_id, COUNT(*) AS cnt
    FROM base
    GROUP BY pipeline, trip_id
  )
  GROUP BY pipeline
),
conf AS (
  SELECT
    pipeline,
    100.0 * AVG(CASE WHEN duration_min BETWEEN 1 AND 24*60 THEN 1 ELSE 0 END) AS pct_duration_ok
  FROM base
  GROUP BY pipeline
),
cons AS (
  SELECT
    'ELT' AS pipeline,
    100.0 * AVG(CASE WHEN end_time >= start_time THEN 1 ELSE 0 END) AS pct_temporal_ok
  FROM `{{PROJECT_ID}}.{{ELT_DATASET_SILVER}}.bikeshare_trips_clean`
  UNION ALL
  SELECT
    'ETL' AS pipeline,
    100.0 * AVG(CASE WHEN end_time >= start_time THEN 1 ELSE 0 END) AS pct_temporal_ok
  FROM `{{PROJECT_ID}}.{{ETL_DATASET}}.bikeshare_trips_clean`
)
SELECT
  COALESCE(n.pipeline, d.pipeline, c.pipeline, s.pipeline) AS pipeline,
  n.pct_null_trip_id, n.pct_null_date_key, n.pct_null_start_station, n.pct_null_end_station, n.pct_null_duration,
  d.pct_duplicidade,
  c.pct_duration_ok,
  s.pct_temporal_ok
FROM nulos n
JOIN dups d USING (pipeline)
JOIN conf c USING (pipeline)
JOIN cons s USING (pipeline)
ORDER BY pipeline;

# Parte 2 — SQL (ELT + Métricas + Qualidade)

**Como usar**
1. Substitua os placeholders:
   - `{{PROJECT_ID}}` → seu projeto GCP
   - `{{REGION}}` → ex.: `us` (use `region-us` nas INFORMATION_SCHEMA)
   - `{{ELT_DATASET_RAW}}`, `{{ELT_DATASET_SILVER}}`, `{{ELT_DATASET_GOLD}}`, `{{ETL_DATASET}}`
   - `{{DATE_START}}`, `{{DATE_END}}` (período analisado)
2. Execute na ordem os arquivos da pasta `sql/elt` e depois rode as queries de `sql/metrics` e `sql/quality`.

## Ordem sugerida
1. `sql/elt/01_create_datasets.sql`
2. `sql/elt/02_ingest_raw.sql`
3. `sql/elt/03_transform_silver.sql`
4. `sql/elt/04_build_gold.sql`
5. `sql/metrics/10_jobs_parsed.sql`
6. `sql/metrics/11_pipeline_summary.sql` (declare `@PRICE_PER_TIB_USD`)
7. `sql/metrics/12_storage_usage.sql`
8. `sql/quality/20_quality_checks.sql`
